cd .. && cp ModernDOS8x8.ttf ~/.termux/font.ttf && termux-reload-settings
