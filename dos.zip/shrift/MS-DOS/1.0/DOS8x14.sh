cd .. && cp ModernDOS8x14.ttf ~/.termux/font.ttf && termux-reload-settings
