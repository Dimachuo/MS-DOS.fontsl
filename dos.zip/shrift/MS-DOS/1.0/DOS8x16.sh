cd .. && cp ModernDOS8x16.ttf ~/.termux/font.ttf && termux-reload-settings
