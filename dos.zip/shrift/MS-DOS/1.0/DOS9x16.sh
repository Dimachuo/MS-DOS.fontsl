cd .. && cp ModernDOS9x16.ttf ~/.termux/font.ttf && termux-reload-settings
