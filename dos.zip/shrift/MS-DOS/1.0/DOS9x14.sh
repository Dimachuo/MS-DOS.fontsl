cd .. && cp ModernDOS9x14.ttf ~/termux/font.ttf && termux-reload-settings
